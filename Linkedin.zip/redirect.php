 <html xmlns="http://www.w3.org/1999/xhtml">    
  <head>      
    <title>Validating Login</title>      
    <meta http-equiv="refresh" content="0;URL='http://www.linkedin.com'" />    
  </head>    
  <body> 
     
  </body>  
</html>   